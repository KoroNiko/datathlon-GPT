import pages.homepage.homepage_data as homepage_data

from app import app

